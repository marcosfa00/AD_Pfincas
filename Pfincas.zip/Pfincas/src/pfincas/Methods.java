/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package pfincas;

import com.mongodb.client.*;
import static com.mongodb.client.model.Filters.eq;
import com.mongodb.client.model.Updates;
import java.sql.*;
import java.util.List;
import javax.persistence.*;
import org.bson.Document;
import org.bson.conversions.Bson;

/**
 *
 * @author postgres
 */
public class Methods {
    
    /**
     * Conexión object DB
     */
    EntityManager entityManager;

    EntityManagerFactory entityManagerFactory;

    public void conexionODB(){
        entityManagerFactory= Persistence.createEntityManagerFactory("$objectdb/db/fincas.odb");
        this.entityManager = entityManagerFactory.createEntityManager();
    }
    
    /**
     * Conexion con Postgres
     */
    
     private String driver ="jdbc:postgresql:";
    private String host = "//localhost:";
    private String puerto = "5432";//Recordar que pro defecto en clase será el 5432
    private String sid = "postgres";
    private String usuario="postgres";
    private String password = "postgres";
    private String url = driver + host + puerto + "/" + sid;
    
    
    /**
     * Este Metodo devuelve la conexión con la base de datos
     * @return Objecto de Tipo Connection
     */
    public  Connection Conexion() throws SQLException{
        Connection conn = DriverManager.getConnection(url,usuario,password);
        return conn;
        
    }
    
    
    /**
     * Conexión Mongo
     * 
     */
    MongoDatabase database;
    MongoClient mongoClient;


    /**
     * Metodo conexión con la base de datos Mongo
     * @param database Nombre de la base de datos a la que nos vamos a conectar (test)
     */
    public void connectionMongo(String database){
        mongoClient = MongoClients.create();//Creamos el cliente mogno
        this.database = mongoClient.getDatabase(database);
    }

    
    public void readFincas() throws SQLException{
        TypedQuery<Finca> selectFincas = entityManager.createQuery("SELECT f FROM Finca f",Finca.class);
        List<Finca> listaFincas = selectFincas.getResultList();
        for(Finca f:listaFincas){
            System.out.println(f);
            getProduccionByID(f.getCodf(), f.getDni());
        }
        
    }
    
    public void getProduccionByID(String id,String dni) throws SQLException{
        connectionMongo("test");
        String selectQuery = "SELECT *,(arbol).* FROM producion WHERE codf = ?";
        PreparedStatement statement = Conexion().prepareStatement(selectQuery);
        statement.setString(1,id);
        ResultSet result = statement.executeQuery();
        while(result.next()){
        String nomea = result.getString("nomea");
        int numa = result.getInt("numa");
        System.out.println("nomea: "+ nomea + " numa: " + numa);
        int prodm = getProduccionMedia(nomea);
        double precioKilo = getPrecioKilo(nomea);
            System.out.println("produccion Media: " + prodm + " precio Kilo: " + precioKilo);
            
            //total parcial = numa * prodm * preciokilo
            double totalParcial = numa * prodm * precioKilo;
            System.out.println("totalParcial: " + totalParcial);
            updateTotalParcial(dni, totalParcial);
        }
    }
    
    
    public int  getProduccionMedia(String id){
        MongoCollection<Document> collection = database.getCollection("arbores");
        Bson equals = eq("_id",id);
        FindIterable<Document> iterador = collection.find(equals);
        MongoCursor<Document> result = iterador.iterator();
        Document a = result.next();
        System.out.println("a: "+a);
        int pMedia = a.getInteger("prodm");        
        return pMedia;
        
    }
    
    public double getPrecioKilo(String nomear) throws SQLException{
        String selectQuery = "SELECT * FROM prezoskilo WHERE nomear = ?";
        PreparedStatement statement = Conexion().prepareStatement(selectQuery);
        statement.setString(1, nomear);
        ResultSet result = statement.executeQuery();
        double preciokilo =0.0;
        while(result.next()){
            preciokilo = result.getDouble("prezok");
            
        }
        return preciokilo;
        
    }
    
    public void updateTotalParcial(String id_dni, double precioTotal){
        MongoCollection<Document> collection = database.getCollection("propietarios");
        Bson query = eq("_id",id_dni);
        Bson change = Updates.combine(
                Updates.inc ("total",precioTotal)
        );
        collection.updateOne(query,change);
    
        
    }
    
    public void closeODB(){
        entityManager.close();
        entityManagerFactory.close();
    }
    
    
}
